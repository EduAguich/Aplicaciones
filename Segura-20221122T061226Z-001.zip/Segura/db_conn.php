<?php

    $sname = "localhost";
    $unmae = "root";
    $pass = "";

    $db_name = "app_segura";

    $conn = msqli_connect($sname, $unmae, $pass, $db_name);

    if(!$conn) {
        echo("Connection Failed");
    }