<?php
# Redireccionar al formulario y ya
header("Location: formulario.html");
?>